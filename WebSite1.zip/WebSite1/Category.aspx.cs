﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Book_Category : System.Web.UI.Page
{
    string str = ConfigurationManager.ConnectionStrings["cnStr"].ConnectionString;
    SqlConnection cn;
    protected void Page_Load(object sender, EventArgs e)
    {
        cn = new SqlConnection(str);
        cn.Open();
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string str;
        str = "insert into tblCategory values('" + txtCategory.Text + "','" + CatImg.FileName + "')";
        SqlCommand cmd = new SqlCommand(str, cn);
        cmd.ExecuteNonQuery();
    }
    void fillCategory()
    {
        str="select * from tblCategory":
        SqlCommand cmd = new SqlCommand(str,cn);
        SqlDataAdapter da  = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        grdCategory.DataSource = ds;
        grdCategory.DataBind();
    }
}